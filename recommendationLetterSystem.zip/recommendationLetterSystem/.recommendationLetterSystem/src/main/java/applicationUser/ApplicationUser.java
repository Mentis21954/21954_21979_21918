package applicationUser;

public class ApplicationUser implements UserDetails{
}
